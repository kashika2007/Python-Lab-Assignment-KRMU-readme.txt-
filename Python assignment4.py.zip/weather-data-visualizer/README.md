# Weather Data Visualizer

This project analyzes real-world weather data using Python. It performs data cleaning, statistical analysis, visualizations, and exports insights for reporting.

## Tools Used
- Pandas
- NumPy
- Matplotlib

## Features
- Cleans and filters weather data
- Computes mean, min, max, standard deviation
- Monthly aggregation
- Line, bar, scatter, and combined plots
- Generates cleaned CSV and summary report

## How to Run
Place your dataset as `weather.csv` in the project folder and run:
```
python main.py
```

## Files Generated
- cleaned_weather.csv
- daily_temperature.png
- monthly_rainfall.png
- scatter_humidity_temp.png
- combined_plot.png
- summary_report.txt
