import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.read_csv("weather.csv")
df['Date'] = pd.to_datetime(df['Date'])
df = df.dropna(subset=['Temperature', 'Rainfall', 'Humidity'])
df = df[['Date', 'Temperature', 'Rainfall', 'Humidity']]

daily_mean = np.mean(df['Temperature'])
daily_min = np.min(df['Temperature'])
daily_max = np.max(df['Temperature'])
daily_std = np.std(df['Temperature'])

df['Month'] = df['Date'].dt.month
monthly_stats = df.groupby('Month').agg(['mean','min','max','std'])

plt.figure()
plt.plot(df['Date'], df['Temperature'])
plt.title("Daily Temperature Trend")
plt.xlabel("Date")
plt.ylabel("Temperature (°C)")
plt.savefig("daily_temperature.png")
plt.show()

monthly_rain = df.groupby('Month')['Rainfall'].sum()
plt.figure()
plt.bar(monthly_rain.index, monthly_rain.values)
plt.title("Monthly Rainfall Totals")
plt.xlabel("Month")
plt.ylabel("Rainfall (mm)")
plt.savefig("monthly_rainfall.png")
plt.show()

plt.figure()
plt.scatter(df['Temperature'], df['Humidity'])
plt.title("Humidity vs Temperature")
plt.xlabel("Temperature (°C)")
plt.ylabel("Humidity (%)")
plt.savefig("scatter_humidity_temp.png")
plt.show()

plt.figure(figsize=(10,5))
plt.subplot(1,2,1)
plt.plot(df['Date'], df['Temperature'])
plt.title("Temperature Trend")
plt.subplot(1,2,2)
plt.scatter(df['Temperature'], df['Humidity'])
plt.title("Temp vs Humidity")
plt.savefig("combined_plot.png")
plt.show()

df.to_csv("cleaned_weather.csv", index=False)

with open("summary_report.txt", "w") as f:
    f.write("WEATHER DATA ANALYSIS REPORT\n")
    f.write("-----------------------------------\n")
    f.write(f"Average Temperature: {daily_mean:.2f} °C\n")
    f.write(f"Minimum Temperature: {daily_min:.2f} °C\n")
    f.write(f"Maximum Temperature: {daily_max:.2f} °C\n")
    f.write(f"Temperature Std Dev: {daily_std:.2f}\n\n")
    f.write("Monthly Statistics:\n")
    f.write(str(monthly_stats))
    f.write("\n\nKey Insight:\n")
    f.write("Temperature trends, rainfall peaks, and humidity relationships were observed and visualized.\n")

print("Analysis complete. Generated files ready for submission.")
